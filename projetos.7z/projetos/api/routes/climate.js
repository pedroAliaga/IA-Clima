module.exports = app => {
    const controller = require('../controllers/climate')();
  
    app.route('/api/v1/climate')
      .get(controller.listClimate);
  }